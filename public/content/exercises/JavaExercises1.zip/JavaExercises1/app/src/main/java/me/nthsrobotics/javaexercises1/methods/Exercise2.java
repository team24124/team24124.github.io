package me.nthsrobotics.javaexercises1.methods;

/**
 * TASK OUTLINE:
 * Create an array of strings containing the following values:
 * Robot, Servo, Motor, Android Studio, Odometry
 * ---
 * Write the search() method
 *  1) The method will take TWO parameters, an array of strings, and a string to search for
 *  2) The method will return a boolean, true if the array contains the string, false otherwise.
 *  Test your method using the array you created above.
 * ---
 * RIGHT CLICK your main method to test your code.
 * USE the unit tests in Exercise2UnitTest.java to validate your solutions.
 */
public class Exercise2 {
    public static void main(String[] args) {

    }

    public static boolean search(String[] arr, String target){
        throw new UnsupportedOperationException("This method is implemented yet!");
    }
}
