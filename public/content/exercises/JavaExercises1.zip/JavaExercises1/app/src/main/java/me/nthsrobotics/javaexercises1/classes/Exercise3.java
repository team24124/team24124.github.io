package me.nthsrobotics.javaexercises1.classes;

/**
 * TASK OUTLINE:
 * Create the DriveTrain class.
 *  1) Create the PRIVATE attribute "motorName"
 *  2) Create the PRIVATE attribute "speeds" containing an array of the following speeds: 0.2, 0.5, 1.0
 *  3) Create the PRIVATE attribute "speedIndex" that holds the INDEX of the current speed (default: 0)
 *  4) Create a CONSTRUCTOR that sets the motor to a given parameter
 *  5) Create the getCurrentSpeed() method
 *  6) Create the nextSpeed() method
 *  7) Crete the previousSpeed() method
 *  8) Create the getSpeedIndex() method
 * ---
 * Method Specifications
 * The method, "nextSpeed()" should take NO parameters and increment the speedIndex by 1
 * do not let the currentSpeed index be larger than the array.
 * The method, "previousSpeed()" should take NO parameters and decrement the speedIndex by 1
 * do not let the currentSpeed index be less than zero.
 * The method, getCurrentSpeed() should return the currently selected speed from the speeds array
 * The method, getSpeedIndex() should be a getter for the speedIndex.
 * ---
 * Test your class using the main method below.
 * RIGHT CLICK your main method to run your code.
 */
public class Exercise3 {
    public static void main(String[] args) {

    }
}
