package me.nthsrobotics.javaexercises1.solutions;

public class Exercise2Solutions {
    public static void main(String[] args) {
        System.out.println(search(new String[]{"a", "b", "c"}, "c")); // True
        System.out.println(search(new String[]{"a", "b", "c"}, "d")); // False
    }

    public static boolean search(String[] arr, String target){
        for(String str : arr){
            if(str.equals(target)) return true;
        }

        return false;
    }
}
