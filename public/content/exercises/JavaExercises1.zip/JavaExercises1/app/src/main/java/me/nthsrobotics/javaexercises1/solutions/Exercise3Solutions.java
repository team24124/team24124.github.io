package me.nthsrobotics.javaexercises1.solutions;

public class Exercise3Solutions {
    public static void main(String[] args) {
        DriveTrain driveTrain = new DriveTrain("main motor");
        System.out.println(driveTrain.getCurrentSpeed()); // 0.2
        driveTrain.nextSpeed();
        System.out.println(driveTrain.getCurrentSpeed()); // 0.5
        System.out.println(driveTrain.getSpeedIndex()); // 1
        driveTrain.previousSpeed();
        System.out.println(driveTrain.getSpeedIndex()); // 0
    }
}

class DriveTrain {
    private double[] speeds = {0.2, 0.5, 1.0};
    private int speedIndex = 0;

    private String motorName;

    public DriveTrain(String motorName){
        this.motorName = motorName;
    }

    public void nextSpeed(){
        if(speedIndex + 1 <= speeds.length - 1) speedIndex++;
    }

    public void previousSpeed(){
        if(speedIndex - 1 >= 0) speedIndex--;
    }

    public double getCurrentSpeed(){
        return speeds[speedIndex];
    }

    public int getSpeedIndex(){
        return speedIndex;
    }
}
