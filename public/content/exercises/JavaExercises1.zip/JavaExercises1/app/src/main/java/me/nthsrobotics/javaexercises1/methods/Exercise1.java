package me.nthsrobotics.javaexercises1.methods;

/**
 * TASK OUTLINE:
 * Create THREE variables in the main method below
 *  1) A string to hold the name, Gary
 *  2) An integer to hold the age, 13
 *  3) A string to hold Gary's favorite color, blue
 *  ---
 * Write the greeting() method
 *  1) The method should be PUBLIC and STATIC
 *  2) The greeting() method should take three parameters in order: Name, age and favorite color
 *  3) The method should RETURN a string value formatted like the following:
 *  "Hello, my name is [Name]! I am [age] years old and my favorite color is [favorite color]."
 *  Test your method using the variables created above.
 *  ---
 *  RIGHT CLICK your main method to test your code.
 *  USE the unit tests in Exercise1UnitTest.java to validate your solutions.
 */
public class Exercise1 {
    public static void main(String[] args) {

    }
}
