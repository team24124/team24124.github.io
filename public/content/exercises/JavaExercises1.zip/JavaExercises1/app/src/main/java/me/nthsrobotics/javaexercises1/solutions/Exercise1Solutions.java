package me.nthsrobotics.javaexercises1.solutions;

public class Exercise1Solutions {
    public static void main(String[] args) {
        String name = "Gary";
        int age = 13;
        String favoriteColor = "blue";

        System.out.println(greetings(name, age, favoriteColor));
    }

    public static String greetings(String name, int age, String favColor){
        return "Hello, my name is " + name + "! I am " + age + " years old and my favorite color is " + favColor +  ".";
    }
}