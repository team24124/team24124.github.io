package me.nthsrobotics.javaexercises1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

import org.junit.Test;

import java.lang.reflect.Method;

import me.nthsrobotics.javaexercises1.methods.Exercise1;
import me.nthsrobotics.javaexercises1.solutions.Exercise1Solutions;

public class Exercise1UnitTest {
    @Test
    public void greetingMethod_exists() {
        try{
            Method greetings = Exercise1.class.getMethod("greetings", String.class, int.class, String.class);
            assertNotNull(greetings);
        }catch (NoSuchMethodException e){
            fail("It does not seem like you created the greetings() method!");
        }
    }

    @Test
    public void greetingMethod_isCorrect() {
        try{
            Method greetings = Exercise1.class.getMethod("greetings", String.class, int.class, String.class);
            assertNotNull(greetings);

            String name = "Robert";
            int age = 17;
            String favoriteColor = "red";

            assertEquals("Hello, my name is Robert! I am 17 years old and my favorite color is red.".toUpperCase(), Exercise1.greetings(name, age, favoriteColor).toUpperCase());
        }catch (NoSuchMethodException e){
            fail("It does not seem like you created the greetings() method!");
        }
    }
}
