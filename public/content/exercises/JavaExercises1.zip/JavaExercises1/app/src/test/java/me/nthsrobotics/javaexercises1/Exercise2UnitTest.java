package me.nthsrobotics.javaexercises1;

import org.junit.Assert;
import org.junit.Test;

import me.nthsrobotics.javaexercises1.methods.Exercise2;
import me.nthsrobotics.javaexercises1.solutions.Exercise2Solutions;

public class Exercise2UnitTest {
    @Test
    public void startsWithVowel_isCorrect(){
        String[] test = {"i", "love", "robotics", "at", "nths"};

        Assert.assertTrue(Exercise2Solutions.search(test, "robotics"));
        Assert.assertFalse(Exercise2Solutions.search(test, "mandela"));
    }
}
